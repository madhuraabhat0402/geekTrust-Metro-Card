package com.example.geektrust.configuration;

public class Constants {
	public static final int PRICE_FOR_ADULT = 200;
	public static final int PRICE_FOR_KID = 50;
	public static final int PRICE_FOR_SENIOR_CITIZEN = 100;
	public static final float SERVICE_CHARGE = (float) 0.02;

}
