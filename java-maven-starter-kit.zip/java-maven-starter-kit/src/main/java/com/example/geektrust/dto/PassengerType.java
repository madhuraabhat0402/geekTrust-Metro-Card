package com.example.geektrust.dto;

public enum PassengerType {
	ADULT, KID, SENIOR_CITIZEN
}
