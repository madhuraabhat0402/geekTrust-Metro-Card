package com.example.geektrust.dto;

public enum MetroStationName {

	CENTRAL, AIRPORT
}
