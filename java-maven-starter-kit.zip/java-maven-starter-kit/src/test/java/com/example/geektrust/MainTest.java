package com.example.geektrust;

import org.junit.Test;


public class MainTest {
	@Test
	void contextLoads() {
		org.junit.Assert.assertFalse(false);
	}

}