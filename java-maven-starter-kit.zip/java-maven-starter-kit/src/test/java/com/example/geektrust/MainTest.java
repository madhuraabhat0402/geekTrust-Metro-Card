package com.example.geektrust;

import org.junit.jupiter.api.Test;


public class MainTest {
	@Test
	void contextLoads() {
		org.junit.Assert.assertFalse(false);
	}

}